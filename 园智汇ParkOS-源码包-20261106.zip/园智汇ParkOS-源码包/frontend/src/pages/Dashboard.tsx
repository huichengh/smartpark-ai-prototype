/**
 * 数据驾驶舱
 *
 * 所有指标与图表均由 /dashboard/summary 动态返回，前端不做任何指标硬编码。
 * 每个 KPI 都展示后端给出的 `basis`（计算口径）与 `data_status`，
 * 满足「可解释、可追踪、可回溯」的要求 —— 用户能看清数字是怎么算出来的。
 */
import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Activity,
  AlertTriangle,
  Building2,
  CircleDollarSign,
  FileSignature,
  Handshake,
  Info,
  Layers,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  Users,
} from 'lucide-react'
import { dashboardApi, agentApi } from '@/api/modules'
import { useAuth } from '@/context/AuthContext'
import { useAsync, pushToast } from '@/hooks/useAsync'
import {
  Btn,
  DemoBadge,
  EmptyState,
  ErrorState,
  KpiCard,
  Loading,
  PageHeader,
  Panel,
  ProgressBar,
  StatLine,
  Tag,
  cx,
} from '@/components/ui'
import { Chart, barOption, lineOption, pieOption, funnelOption, rankBarOption, RISE, FALL } from '@/components/Charts'

/** KPI 图标按 key 映射（纯展示，不含业务数据） */
/**
 * KPI 数值可读化：超过一万的数按「万 / 亿」换算，单位跟着变。
 *
 * 原样渲染会出现「47640476.88 kWh」这种 8 位数，卡片宽度撑不住，
 * 视频里也读不出量级。百分比、个数类指标保持原样。
 */
/** KPI 的白话解释：卡片上只留一句人话，计算公式挂到悬停提示里 */
const KPI_PLAIN: Record<string, string> = {
  park_count: '你能看到的园区有几个',
  enterprise_count: '建档企业总数（含意向与已退园）',
  settle_rate: '已入驻占可容纳的比例',
  occupancy_rate: '已租面积占可租面积的比例',
  available_area: '现在能招租的空置面积',
  lead_count: '手上正在跟的招商线索',
  conversion_rate: '线索最终签下来的比例',
  contract_expiring: '90 天内到期的合同数',
  collection_rate: '应收租金实际收回的比例',
  arrears_amount: '还没收回来的欠费',
  work_order_rate: '报修工单处理完的比例',
  device_online_rate: '设备在线的比例',
  energy_total: '本月用电量',
  safety_risk: '还没闭环的安全事件数',
  project_active: '正在施工的项目数',
  project_delayed: '拖过计划完工日的项目',
  budget_execution: '项目预算花了多少',
  monthly_income: '本月实际收到多少钱',
}

function scaleKpi(value: any, unit?: string): { v: any; u?: string } {
  if (value == null || typeof value !== 'number') return { v: value ?? '—', u: unit }
  const abs = Math.abs(value)
  if (unit === '%' || (unit && unit !== 'kWh' && unit !== '元' && unit !== '㎡')) {
    return { v: value, u: unit }
  }
  if (abs >= 1e8) return { v: (value / 1e8).toFixed(2), u: unit ? `亿 ${unit}` : '亿' }
  if (abs >= 1e4) return { v: (value / 1e4).toFixed(1), u: unit ? `万 ${unit}` : '万' }
  return { v: value, u: unit }
}

const KPI_ICON: Record<string, JSX.Element> = {
  park_count: <Building2 size={15} />,
  enterprise_count: <Users size={15} />,
  settle_rate: <TrendingUp size={15} />,
  occupancy_rate: <Layers size={15} />,
  available_area: <Building2 size={15} />,
  lead_count: <Handshake size={15} />,
  conversion_rate: <Activity size={15} />,
  contract_expiring: <FileSignature size={15} />,
  collection_rate: <CircleDollarSign size={15} />,
  project_total: <Layers size={15} />,
  safety_score: <ShieldCheck size={15} />,
}

/** data_status 到视觉色调的映射 */
function statusTone(s?: string) {
  if (!s) return 'muted'
  if (s.includes('异常') || s.includes('风险')) return 'danger'
  if (s.includes('提醒') || s.includes('预警')) return 'warn'
  if (s.includes('正常')) return 'ok'
  return 'muted'
}

export default function Dashboard() {
  const { activeParkId, user } = useAuth()
  const nav = useNavigate()
  const [detail, setDetail] = useState<string | null>(null)

  const { data, loading, error, reload } = useAsync(
    () => dashboardApi.summary(activeParkId),
    [activeParkId],
  )
  const alerts = useAsync(() => dashboardApi.alerts(activeParkId), [activeParkId])
  const insight = useAsync(() => agentApi.dailyInsight(activeParkId), [activeParkId])

  const kpis = useMemo(() => (data?.kpis ?? []) as any[], [data])
  const charts = (data?.charts ?? {}) as Record<string, any[]>
  const summary = (data?.summary ?? {}) as Record<string, any>

  if (loading && !data) return <Loading text="正在加载驾驶舱数据…" />
  if (error) return <ErrorState error={error} onRetry={reload} />
  if (!data) return <EmptyState text="暂无驾驶舱数据" />

  const scope = data.scope ?? {}
  const notes = (data.data_status_notes ?? []) as any[]

  return (
    <div className="space-y-5">
      <PageHeader
        title="数据驾驶舱"
        demo
        desc={
          <>
            当前视图：
            <span className="text-slate-300">
              {scope.park_name ?? '全部园区'}
            </span>
            {scope.data_scope ? ` · 数据范围 ${scope.data_scope}` : ''}
            {data.updated_at ? ` · 数据时间 ${String(data.updated_at).replace('T', ' ')}` : ''}
          </>
        }
        extra={
          <Btn onClick={reload} loading={loading}>
            <RefreshCw size={13} /> 刷新数据
          </Btn>
        }
      />

      {/* 数据质量提示：后端明确告知哪些指标数据不完整 */}
      {notes.length > 0 && (
        <div className="flex items-start gap-2.5 rounded-card border border-state-warn/28 bg-state-warn/[0.07] px-4 py-3">
          <Info size={15} className="mt-0.5 shrink-0 text-state-warn" />
          <div className="min-w-0 text-[12px] leading-relaxed text-slate-300">
            <span className="font-medium text-state-warn">数据完整性提示：</span>
            {notes.map((n, i) => (
              <span key={i}>
                {i > 0 && '；'}
                {n.label ?? n.key}
                {n.note ? ` —— ${n.note}` : ''}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* KPI 网格 */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-6">
        {kpis.map((k) => {
          const tone =
            k.key === 'safety_score'
              ? 'ok'
              : k.data_status && k.data_status !== '正常'
                ? 'warn'
                : 'brand'
          return (
            <button
              key={k.key}
              onClick={() => setDetail(k.key)}
              className="text-left"
              title="点击查看计算口径"
            >
              <KpiCard
                label={k.label}
                value={scaleKpi(k.value, k.unit).v}
                unit={scaleKpi(k.value, k.unit).u}
                delta={k.mom}
                deltaLabel="环比"
                icon={KPI_ICON[k.key] ?? <Activity size={15} />}
                tone={tone}
                hint={
                  k.target
                    ? `目标 ${k.target}${k.unit ?? ''}`
                    : (k.unavailable_reason || KPI_PLAIN[k.key] || undefined)
                }
                // 带目标的指标，卡片上保留"目标"（这是判断好坏的关键信号），
                // 白话解释和计算口径一起放进悬停，两者都不丢
                explain={
                  [KPI_PLAIN[k.key], k.basis,
                   k.target ? `目标 ${k.target}${k.unit ?? ''}` : '']
                    .filter(Boolean).join('；')
                }
              />
            </button>
          )
        })}
      </div>

      {/* 指标口径抽屉 */}
      {detail && (
        <div
          className="fixed inset-0 z-50 flex items-start justify-center bg-black/50 p-4 pt-20 backdrop-blur-sm"
          onClick={() => setDetail(null)}
        >
          <div
            className="w-full max-w-lg animate-fade-up rounded-panel border border-white/12 bg-nav-panel/97 p-5 shadow-glass backdrop-blur-xl"
            onClick={(e) => e.stopPropagation()}
          >
            {(() => {
              const k = kpis.find((x) => x.key === detail)
              if (!k) return null
              return (
                <>
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-base font-semibold text-slate-50">{k.label}</h3>
                      <div className="mt-1.5 flex items-baseline gap-1.5">
                        <span className="font-num text-kpi-sm font-semibold text-brand-400">
                          {k.value ?? '—'}
                        </span>
                        <span className="text-xs text-slate-400">{k.unit}</span>
                      </div>
                    </div>
                    <Tag tone={statusTone(k.data_status)}>{k.data_status ?? '正常'}</Tag>
                  </div>

                  <div className="mt-4 space-y-3 text-[13px]">
                    <div>
                      <p className="mb-1 text-xs font-medium text-slate-400">计算口径</p>
                      <p className="leading-relaxed text-slate-300">{k.basis ?? '未提供口径说明'}</p>
                    </div>
                    <StatLine
                      items={[
                        { label: '目标值', value: k.target != null ? `${k.target}${k.unit ?? ''}` : '未设定' },
                        { label: '趋势', value: k.trend ?? '—' },
                        { label: '环比', value: k.mom != null ? `${k.mom}%` : '—' },
                        { label: '同比', value: k.yoy != null ? `${k.yoy}%` : '—' },
                      ]}
                    />
                    {k.link && (
                      <Btn size="sm" onClick={() => { setDetail(null); nav(k.link) }}>
                        前往相关模块查看明细
                      </Btn>
                    )}
                  </div>
                </>
              )
            })()}
          </div>
        </div>
      )}

      {/* 图表区 */}
      <div className="grid gap-4 xl:grid-cols-3">
        {/* 招商漏斗 */}
        <Panel
          title="招商转化漏斗"
          subtitle="各阶段线索到达数量"
          icon={<Handshake size={15} />}
          extra={<Btn size="sm" variant="ghost" onClick={() => nav('/leasing')}>查看明细</Btn>}
        >
          <Chart
            height={272}
            empty={!charts.funnel?.length}
            option={funnelOption({
              data: (charts.funnel ?? []).map((f: any) => ({
                name: f.stage_name ?? f.stage,
                value: f.reached ?? f.count,
              })),
            })}
          />
        </Panel>

        {/* 线索与签约趋势 */}
        <Panel
          title="线索获取与签约趋势"
          subtitle="按月统计线索量、签约量与转化率"
          icon={<TrendingUp size={15} />}
        >
          <Chart
            height={272}
            empty={!charts.lead_trend?.length}
            option={lineOption({
              x: (charts.lead_trend ?? []).map((d: any) => d.month),
              series: [
                { name: '新增线索', data: (charts.lead_trend ?? []).map((d: any) => d.leads), color: '#2F80ED' },
                { name: '签约', data: (charts.lead_trend ?? []).map((d: any) => d.signs), color: '#22C55E' },
              ],
              area: true,
            })}
          />
        </Panel>

        {/* 企业经营状态 */}
        <Panel
          title="企业构成"
          subtitle="按经营状态分布"
          icon={<Users size={15} />}
        >
          <Chart
            height={272}
            empty={!charts.status_dist?.length}
            option={pieOption({
              data: (charts.status_dist ?? []).map((d: any) => ({ name: d.name, value: d.value })),
              centerLabel: {
                // 中心必须等于环内各分段之和。原来取的是 enterprise_settled（在园企业 249），
                // 而环里画的是全部四种状态（344），中心数和图对不上，看着像算错了。
                title: '企业总数',
                value: (charts.status_dist ?? []).reduce((s: number, x: any) => s + (x.value ?? 0), 0)
                  || summary.enterprise_settled || 0,
              },
            })}
          />
        </Panel>

        {/* 楼栋出租率对比 */}
        <Panel
          title="楼栋出租率对比"
          subtitle="已租面积 / 可租面积"
          icon={<Building2 size={15} />}
          className="xl:col-span-2"
          extra={<Btn size="sm" variant="ghost" onClick={() => nav('/twin')}>数字孪生视图</Btn>}
        >
          <Chart
            height={260}
            empty={!charts.space_by_building?.length}
            option={barOption({
              x: (charts.space_by_building ?? []).map((b: any) => b.building_name),
              series: [
                {
                  name: '出租率(%)',
                  data: (charts.space_by_building ?? []).map((b: any) => b.occupancy_rate),
                  color: '#2F80ED',
                },
              ],
              showLegend: false,
            })}
          />
        </Panel>

        {/* 欠费账龄 */}
        <Panel
          title="欠费账龄结构"
          subtitle="逾期账龄分档金额"
          icon={<CircleDollarSign size={15} />}
          extra={<Btn size="sm" variant="ghost" onClick={() => nav('/finance')}>财务明细</Btn>}
        >
          <Chart
            height={260}
            empty={
              !charts.arrears_age?.length ||
              (charts.arrears_age ?? []).every((a: any) => !a.value)
            }
            option={barOption({
              x: (charts.arrears_age ?? []).map((a: any) => a.name),
              series: [
                {
                  name: '金额',
                  data: (charts.arrears_age ?? []).map((a: any) => a.value),
                  color: '#F97316',
                },
              ],
              showLegend: false,
            })}
          />
        </Panel>

        {/* 财务趋势 */}
        <Panel
          title="应收与实收趋势"
          subtitle="按月统计应收、实收与欠费"
          icon={<CircleDollarSign size={15} />}
          className="xl:col-span-2"
        >
          <Chart
            height={252}
            empty={!charts.finance_trend?.length}
            option={lineOption({
              x: (charts.finance_trend ?? []).map((d: any) => d.month),
              series: [
                { name: '应收', data: (charts.finance_trend ?? []).map((d: any) => d.receivable), color: '#2F80ED' },
                { name: '实收', data: (charts.finance_trend ?? []).map((d: any) => d.received), color: '#22C55E' },
                { name: '欠费', data: (charts.finance_trend ?? []).map((d: any) => d.arrears), color: '#EF4444' },
              ],
            })}
          />
        </Panel>

        {/* 项目风险分布 */}
        <Panel
          title="项目风险分布"
          subtitle="在建项目风险等级"
          icon={<AlertTriangle size={15} />}
          extra={<Btn size="sm" variant="ghost" onClick={() => nav('/projects')}>项目中心</Btn>}
        >
          <div className="space-y-3">
            <Chart
              height={180}
              empty={!charts.project_risk_dist?.length}
              option={pieOption({
                data: (charts.project_risk_dist ?? []).map((d: any) => ({
                  name: d.name,
                  value: d.value,
                  color:
                    d.key === 'HIGH' || d.key === 'CRITICAL'
                      ? '#EF4444'
                      : d.key === 'MEDIUM'
                        ? '#FACC15'
                        : '#22C55E',
                })),
                donut: false,
              })}
            />
            <StatLine
              items={[
                { label: '项目总数', value: summary.project_total ?? '—' },
                { label: '瀑布', value: summary.waterfall_count ?? 0 },
                { label: '敏捷', value: summary.agile_count ?? 0 },
                { label: '混合', value: summary.hybrid_count ?? 0 },
              ]}
            />
          </div>
        </Panel>

        {/* 能耗趋势 */}
        <Panel
          title="能耗与碳排趋势"
          subtitle="按月统计各类能源消耗与碳排"
          icon={<Activity size={15} />}
          className="xl:col-span-2"
          extra={<Btn size="sm" variant="ghost" onClick={() => nav('/energy')}>能源管理</Btn>}
        >
          <Chart
            height={248}
            empty={!charts.energy_trend?.length}
            option={lineOption({
              x: (charts.energy_trend ?? []).map((d: any) => d.month),
              series: [
                { name: '电力', data: (charts.energy_trend ?? []).map((d: any) => d.ELECTRICITY), color: '#2F80ED' },
                { name: '用水', data: (charts.energy_trend ?? []).map((d: any) => d.WATER), color: '#00D4FF' },
                { name: '燃气', data: (charts.energy_trend ?? []).map((d: any) => d.GAS), color: '#F97316' },
                { name: '光伏', data: (charts.energy_trend ?? []).map((d: any) => d.PV), color: '#22C55E' },
              ],
            })}
          />
        </Panel>

        {/* 安全状态 */}
        <Panel
          title="安全事件闭环"
          subtitle="按处理状态统计"
          icon={<ShieldCheck size={15} />}
          extra={<Btn size="sm" variant="ghost" onClick={() => nav('/safety')}>安全管理</Btn>}
        >
          <div className="space-y-4">
            <Chart
              height={168}
              empty={
                !charts.safety_status_dist?.length ||
                (charts.safety_status_dist ?? []).every((d: any) => !d.value)
              }
              option={pieOption({
                data: (charts.safety_status_dist ?? [])
                  .filter((d: any) => d.value > 0)
                  .map((d: any) => ({ name: d.name, value: d.value })),
                // 中心放"已闭环率"而不是安全指数：这张卡的标题是"按处理状态统计"，
                // 放一个不相干的指标会让人以为闭环率 = 安全指数
                centerLabel: {
                  title: '已闭环率',
                  value: (() => {
                    const rows = (charts.safety_status_dist ?? []).filter((d: any) => d.value > 0)
                    const total = rows.reduce((a: number, b: any) => a + b.value, 0)
                    const closed = rows.find((d: any) => d.key === 'CLOSED')?.value ?? 0
                    return total ? `${Math.round((closed / total) * 100)}%` : '—'
                  })(),
                },
              })}
            />
            <StatLine
              items={[
                { label: '安全指数', value: summary.safety_score ?? '—' },
                { label: '状态', value: summary.safety_status ?? '—' },
                { label: '能耗异常', value: summary.energy_anomaly_count ?? 0 },
                { label: '待保养设备', value: summary.device_maintain_due ?? 0 },
              ]}
            />
          </div>
        </Panel>
      </div>

      {/* 告警 + AI 洞察 */}
      <div className="grid gap-4 xl:grid-cols-2">
        <Panel
          title="实时告警"
          subtitle="需关注的异常与待办事项"
          icon={<AlertTriangle size={15} />}
          extra={
            alerts.data ? (
              <Tag tone="warn">{`${(alerts.data.items ?? alerts.data.alerts ?? []).length} 条`}</Tag>
            ) : null
          }
        >
          {alerts.loading ? (
            <Loading inline />
          ) : alerts.error ? (
            <ErrorState error={alerts.error} onRetry={alerts.reload} />
          ) : (
            (() => {
              const list = (alerts.data?.items ?? alerts.data?.alerts ?? []) as any[]
              if (list.length === 0) {
                return <EmptyState text="当前无告警" hint="系统运行正常" />
              }
              return (
                <div className="space-y-2">
                  {list.slice(0, 6).map((a, i) => {
                    // 接口返回的是 content / related_module / trigger_value 等字段，
                    // 原来按 description / module 取，全都取不到，于是每行只剩一个标题。
                    const detail = a.content || a.description || ''
                    const module = a.related_module || a.module
                    const sev = a.severity || (a.level === 'danger' ? 'CRITICAL' : 'INFO')
                    const tone = sev === 'CRITICAL' ? 'danger' : sev === 'RISK' ? 'warn' : 'info'
                    const sevLabel = sev === 'CRITICAL' ? '紧急' : sev === 'RISK' ? '风险' : sev === 'WARNING' ? '提醒' : '提示'
                    return (
                      <div
                        key={a.id ?? i}
                        className={cx(
                          'rounded-lg border px-3 py-2.5 transition',
                          sev === 'CRITICAL'
                            ? 'border-state-danger/28 bg-state-danger/[0.07]'
                            : sev === 'RISK'
                              ? 'border-state-warn/28 bg-state-warn/[0.07]'
                              : 'border-white/8 bg-white/[0.03]',
                        )}
                      >
                        <div className="flex items-start gap-2">
                          <span
                            className={cx(
                              'mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full',
                              sev === 'CRITICAL' ? 'bg-state-danger'
                                : sev === 'RISK' ? 'bg-state-warn' : 'bg-brand-400',
                            )}
                          />
                          <div className="min-w-0 flex-1">
                            <div className="flex items-start justify-between gap-2">
                              <p className="text-[13px] leading-snug text-slate-200">
                                {a.title ?? a.label}
                              </p>
                              <span className="flex shrink-0 items-center gap-1">
                                {a.count > 1 && <Tag tone="info">{`${a.count} 条`}</Tag>}
                                <Tag tone={tone as any}>{sevLabel}</Tag>
                              </span>
                            </div>

                            {detail && (
                              <p className="mt-1 line-clamp-2 text-[11px] leading-relaxed text-slate-500">
                                {detail}
                              </p>
                            )}

                            {/* 合并了多条时，触发值/阈值属于其中某一条，展示出来会误导，
                                改为只给条数；单条时才显示具体数值 */}
                            {a.count <= 1 && (a.trigger_value != null || a.threshold != null) && (
                              <p className="mt-1 font-num text-[11px] text-slate-400">
                                当前 {a.trigger_value ?? '—'} / 阈值 {a.threshold ?? '—'}
                              </p>
                            )}
                            {a.count > 1 && (
                              <p className="mt-1 text-[11px] text-slate-400">
                                共 {a.count} 条记录触发同一规则，建议按园区分别处理
                              </p>
                            )}

                            {a.suggestion && (
                              <p className="mt-1 text-[11px] leading-relaxed text-slate-400">
                                <span className="text-slate-500">建议：</span>{a.suggestion}
                              </p>
                            )}

                            <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[10px] text-slate-600">
                              {module && <Tag tone="muted">{module}</Tag>}
                              {a.related_object_name && <span>{a.related_object_name}</span>}
                              {a.occurred_at && <span>{String(a.occurred_at).slice(5, 16).replace('T', ' ')}</span>}
                              {a.action_route && (
                                <button
                                  type="button"
                                  onClick={() => nav(a.action_route)}
                                  className="ml-auto rounded border border-brand-400/40 px-1.5 py-0.5 text-brand-300 transition hover:bg-brand-500/12"
                                >
                                  {a.action_label || '去处理'} ›
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              )
            })()
          )}
        </Panel>

        <Panel
          title={
            <span className="flex items-center gap-2">
              AI 每日洞察
              <Tag tone="ai">
                <Sparkles size={10} /> 园智AI总管
              </Tag>
            </span>
          }
          subtitle={
            insight.data
              ? `基于当前园区数据自动生成 · ${insight.data.model_mode === 'llm' ? '大模型生成' : '规则生成'}`
              : '基于当前园区数据自动生成'
          }
          icon={<Sparkles size={15} />}
        >
          {insight.loading ? (
            <Loading inline />
          ) : insight.error ? (
            <ErrorState error={insight.error} onRetry={insight.reload} />
          ) : (
            <div className="space-y-3">
              {/* 结论 */}
              <div className="rounded-lg border border-ai/25 bg-ai/[0.07] px-3.5 py-3">
                <p className="text-[11px] font-medium text-ai-light">结论</p>
                <p className="mt-1 text-[13px] leading-relaxed text-slate-200">
                  {insight.data?.conclusion ?? insight.data?.summary ?? '暂无洞察结论'}
                </p>
              </div>

              {(() => {
                const d = insight.data ?? {}
                const signals = (d.signals ?? d.key_findings ?? []) as any[]
                const suggestions = (d.suggestions ?? d.actions ?? []) as any[]
                return (
                  <>
                    {signals.length > 0 && (
                      <div>
                        <p className="mb-1.5 text-[11px] font-medium text-slate-400">关键信号</p>
                        <div className="space-y-1.5">
                          {signals.slice(0, 5).map((s, i) => (
                            <div key={i} className="flex items-start gap-2 text-[12px]">
                              <span
                                className={cx(
                                  'mt-1.5 h-1 w-1 shrink-0 rounded-full',
                                  s.level === 'danger'
                                    ? 'bg-state-danger'
                                    : s.level === 'warn'
                                      ? 'bg-state-warn'
                                      : 'bg-brand-400',
                                )}
                              />
                              <span className="leading-relaxed text-slate-300">
                                {typeof s === 'string' ? s : (s.text ?? s.conclusion ?? s.title)}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {suggestions.length > 0 && (
                      <div>
                        <p className="mb-1.5 text-[11px] font-medium text-slate-400">建议措施</p>
                        <div className="space-y-1.5">
                          {suggestions.slice(0, 4).map((s, i) => (
                            <div
                              key={i}
                              className="rounded-lg border border-white/8 bg-white/[0.03] px-3 py-2 text-[12px] leading-relaxed text-slate-300"
                            >
                              {typeof s === 'string'
                                ? s
                                : `${s.title ?? s.action ?? ''}${s.detail ? ` —— ${s.detail}` : ''}`}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {d.data_sufficient === false && (
                      <div className="flex items-start gap-2 rounded-lg border border-state-warn/28 bg-state-warn/[0.07] px-3 py-2 text-[11px] text-state-warn">
                        <Info size={13} className="mt-0.5 shrink-0" />
                        <span>
                          数据不足，AI 无法给出完整结论
                          {d.missing_data ? `（缺少：${Array.isArray(d.missing_data) ? d.missing_data.join('、') : d.missing_data}）` : ''}
                        </span>
                      </div>
                    )}

                    {signals.length === 0 && suggestions.length === 0 && !d.conclusion && !d.summary && (
                      <EmptyState text="暂无 AI 洞察" hint="系统需要更多数据才能生成洞察" />
                    )}
                  </>
                )
              })()}

              <Btn size="sm" variant="ai" onClick={() => nav('/ai')}>
                <Sparkles size={12} /> 进入 AI 对话深入分析
              </Btn>
            </div>
          )}
        </Panel>
      </div>

      {/* 项目与运维摘要 */}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <Panel title="项目管理摘要" subtitle="进度与里程碑">
          <div className="space-y-3">
            <StatLine
              items={[
                { label: '平均进度', value: `${summary.avg_project_progress ?? 0}%` },
              ]}
            />
            <ProgressBar value={summary.avg_project_progress ?? 0} showText />
            <StatLine
              items={[
                { label: '里程碑达成率', value: `${summary.milestone_completion_rate ?? 0}%` },
              ]}
            />
            <ProgressBar value={summary.milestone_completion_rate ?? 0} tone="ok" showText />
            <StatLine
              items={[
                { label: 'Sprint 完成率', value: `${summary.sprint_completion_rate ?? 0}%` },
              ]}
            />
            <ProgressBar value={summary.sprint_completion_rate ?? 0} tone="ai" showText />
          </div>
        </Panel>

        <Panel title="资产概况" subtitle="空间与楼栋">
          <div className="space-y-3">
            <StatLine
              items={[
                { label: '楼栋', value: `${summary.building_count ?? 0} 栋` },
                { label: '可租面积', value: `${((summary.total_rentable_area ?? 0) / 10000).toFixed(2)} 万㎡` },
              ]}
            />
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-lg border border-white/8 bg-white/[0.03] p-3">
                <p className="text-[11px] text-slate-500">已租面积</p>
                <p className="mt-1 font-num text-lg text-brand-400">
                  {((summary.rented_area ?? 0) / 10000).toFixed(2)}
                  <span className="ml-0.5 text-[11px] text-slate-500">万㎡</span>
                </p>
              </div>
              <div className="rounded-lg border border-white/8 bg-white/[0.03] p-3">
                <p className="text-[11px] text-slate-500">空置面积</p>
                <p className="mt-1 font-num text-lg text-state-warn">
                  {((summary.vacant_area ?? 0) / 10000).toFixed(2)}
                  <span className="ml-0.5 text-[11px] text-slate-500">万㎡</span>
                </p>
              </div>
            </div>
          </div>
        </Panel>

        <Panel title="经营概况" subtitle="企业、合同与收缴">
          <div className="space-y-3">
            <StatLine
              items={[
                { label: '入驻企业', value: `${summary.enterprise_settled ?? 0} 家` },
                { label: '风险企业', value: `${summary.enterprise_risk ?? 0} 家` },
              ]}
            />
            <StatLine
              items={[
                { label: '生效合同', value: `${summary.active_contracts ?? 0} 份` },
              ]}
            />
            <div>
              <div className="mb-1 flex items-baseline justify-between">
                <span className="text-[11px] text-slate-500">租金收缴率</span>
                <span className="font-num text-sm text-slate-200">
                  {summary.collection_rate ?? 0}%
                </span>
              </div>
              <ProgressBar
                value={summary.collection_rate ?? 0}
                tone={(summary.collection_rate ?? 0) >= 85 ? 'ok' : 'warn'}
              />
            </div>
          </div>
        </Panel>

        <Panel title="运维概况" subtitle="工单与安全">
          <div className="space-y-3">
            <StatLine
              items={[
                { label: '能耗异常', value: `${summary.energy_anomaly_count ?? 0} 处` },
                { label: '单位能耗', value: summary.unit_energy ?? '—' },
              ]}
            />
            <StatLine
              items={[
                { label: '待保养设备', value: `${summary.device_maintain_due ?? 0} 台` },
              ]}
            />
            <div className="rounded-lg border border-white/8 bg-white/[0.03] px-3 py-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-500">安全指数</span>
                <span
                  className={cx(
                    'font-num text-base font-semibold',
                    (summary.safety_score ?? 0) >= 85
                      ? 'text-state-ok'
                      : (summary.safety_score ?? 0) >= 70
                        ? 'text-state-warn'
                        : 'text-state-danger',
                  )}
                >
                  {summary.safety_score ?? '—'}
                </span>
              </div>
              <p className="mt-0.5 text-[11px] text-slate-500">
                {summary.safety_status ?? '—'}
              </p>
            </div>
          </div>
        </Panel>
      </div>

      {/* 工单趋势 */}
      {charts.work_order_trend?.length > 0 && (
        <Panel title="工单趋势" subtitle="按月统计提交量、关闭量与超时量">
          <Chart
            height={220}
            option={barOption({
              x: charts.work_order_trend.map((d: any) => d.month),
              series: [
                { name: '提交', data: charts.work_order_trend.map((d: any) => d.total), color: '#2F80ED' },
                { name: '关闭', data: charts.work_order_trend.map((d: any) => d.closed), color: '#22C55E' },
                { name: '超时', data: charts.work_order_trend.map((d: any) => d.timeout), color: '#EF4444' },
              ],
            })}
          />
        </Panel>
      )}

      <p className="pb-2 text-center text-[11px] text-slate-600">
        <DemoBadge className="mr-1.5" />
        本平台运行于演示环境，全部业务数据由后端模拟生成，指标口径见各指标悬浮说明。
      </p>
    </div>
  )
}
