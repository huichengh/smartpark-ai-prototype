"""认证与授权核心：密码哈希、JWT、当前用户、数据权限过滤。"""
from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import logging
import os
from typing import Annotated

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db
from app.models import Role, RolePermission, Permission, User, UserParkScope, UserProjectScope

logger = logging.getLogger("smartpark")

oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.API_V1_PREFIX}/auth/login", auto_error=False)

# --------------------------------------------------------------------------
# 密码哈希：优先 bcrypt（passlib），不可用时退化为 PBKDF2-SHA256（纯标准库）
# --------------------------------------------------------------------------
try:  # pragma: no cover - 环境相关
    from passlib.context import CryptContext

    _pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    _HAS_BCRYPT = True
except Exception:  # pragma: no cover
    _pwd_context = None
    _HAS_BCRYPT = False


def hash_password(password: str) -> str:
    if _HAS_BCRYPT and _pwd_context is not None:
        try:
            return _pwd_context.hash(password)
        except Exception:
            pass
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 120_000)
    return f"pbkdf2_sha256${salt.hex()}${dk.hex()}"


def verify_password(password: str, hashed: str) -> bool:
    if hashed.startswith("pbkdf2_sha256$"):
        try:
            _, salt_hex, dk_hex = hashed.split("$")
            dk = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), 120_000)
            return hmac.compare_digest(dk.hex(), dk_hex)
        except Exception:
            return False
    if _HAS_BCRYPT and _pwd_context is not None:
        try:
            return _pwd_context.verify(password, hashed)
        except Exception:
            return False
    return False


# --------------------------------------------------------------------------
# JWT：优先 python-jose，不可用时退化为 HMAC 签名的紧凑令牌
# --------------------------------------------------------------------------
try:  # pragma: no cover
    from jose import JWTError, jwt

    _HAS_JOSE = True
except Exception:  # pragma: no cover
    _HAS_JOSE = False


def _b64url_nopad(raw: bytes) -> str:
    import base64

    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def _fallback_encode(payload: dict) -> str:
    import base64
    import json

    body = base64.urlsafe_b64encode(json.dumps(payload, default=str).encode()).decode().rstrip("=")
    sig = hmac.new(settings.SECRET_KEY.encode(), body.encode(), hashlib.sha256).hexdigest()
    return f"{body}.{sig}"


def _decode_builtin(token: str) -> dict:
    """纯标准库解码，作为 python-jose 的等价兜底实现。

    三个必须同时满足的点（历史上都踩过）：
    1. **同时支持 3 段 JWS 与 2 段紧凑格式**：jose 签的是 `header.payload.sig`，
       本模块早期签的是 `payload.sig`。只认后者会导致"jose 签发、兜底校验"直接失败。
    2. **签名两种编码都要试**：jose 用 base64url(原始摘要)，早期实现用 hexdigest。
       不兼容就出现"自己签的令牌自己验不过"。
    3. **必须校验 exp**：兜底路径曾经完全不看过期时间，等于过期令牌永久有效（真实安全漏洞）。
    """
    import base64
    import json

    parts = token.split(".")
    if len(parts) == 3:
        header_b64, payload_b64, sig = parts
        body = f"{header_b64}.{payload_b64}"
    elif len(parts) == 2:
        payload_b64, sig = parts
        body = payload_b64
    else:
        raise ValueError("token 格式不正确")

    digest = hmac.new(settings.SECRET_KEY.encode(), body.encode(), hashlib.sha256).digest()
    candidates = (digest.hex(), _b64url_nopad(digest))
    if not any(hmac.compare_digest(sig, c) for c in candidates):
        raise ValueError("invalid token signature")

    padded = payload_b64 + "=" * (-len(payload_b64) % 4)
    payload = json.loads(base64.urlsafe_b64decode(padded).decode())

    exp = payload.get("exp")
    if exp is not None and int(exp) <= int(dt.datetime.now(dt.UTC).timestamp()):
        raise ValueError("token 已过期")
    return payload


def create_access_token(data: dict, expires_minutes: int | None = None) -> str:
    expire = dt.datetime.now(dt.UTC) + dt.timedelta(
        minutes=expires_minutes or settings.ACCESS_TOKEN_EXPIRE_MINUTES
    )
    # JWT 的 exp/iat/nbf 必须是 NumericDate（整数秒），传 float 会导致解码端校验失败
    now_ts = int(dt.datetime.now(dt.UTC).timestamp())
    payload = {**data, "exp": int(expire.timestamp()), "iat": now_ts}
    if _HAS_JOSE:
        return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return _fallback_encode(payload)


def decode_token(token: str) -> dict:
    """校验并解出令牌载荷。

    两条实现必须互为兜底：部署环境的可选依赖往往装不全，python-jose 在
    cryptography/ecdsa 缺失时会抛出**非 JWTError** 的异常；早期实现只捕获
    JWTError，于是异常穿透出去变成 401 —— 表现为"登录成功，但所有接口都 401"，
    而本地环境依赖完整、完全复现不出来。这里对所有异常都退到内置实现。
    """
    if _HAS_JOSE:
        try:
            return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        except JWTError as exc:
            # jose 明确判定不合格；内置实现可兜住"签名编码不同"这种兼容性差异，
            # 但同样会校验 exp，不会放宽过期策略。
            try:
                return _decode_builtin(token)
            except Exception:
                raise ValueError(str(exc)) from exc
        except Exception as exc:  # noqa: BLE001 - 依赖后端异常，必须降级而不是 500/401
            logger.warning("python-jose 解码异常，改用内置 HMAC 实现：%s", exc)
            return _decode_builtin(token)
    return _decode_builtin(token)


# --------------------------------------------------------------------------
# 当前用户与权限上下文
# --------------------------------------------------------------------------


class AuthContext:
    """一次请求的完整授权上下文（用户 + 角色 + 权限 + 数据范围）。"""

    def __init__(self, user: User, roles: list[Role], permissions: set[str],
                 park_ids: list[int], project_ids: list[int]):
        self.user = user
        self.roles = roles
        self.permissions = permissions
        self.park_ids = park_ids
        self.project_ids = project_ids

    # ---- 角色判定 ----
    @property
    def role_codes(self) -> set[str]:
        return {r.role_code for r in self.roles}

    @property
    def data_scope(self) -> str:
        """取最宽的数据范围。"""
        order = ["GROUP", "PARK", "DEPARTMENT", "PROJECT", "ENTERPRISE", "SELF"]
        scopes = [r.data_scope for r in self.roles] or ["SELF"]
        for s in order:
            if s in scopes:
                return s
        return "SELF"

    @property
    def is_group_admin(self) -> bool:
        return bool({"GROUP_ADMIN", "SUPER_ADMIN"} & self.role_codes)

    @property
    def is_park_manager(self) -> bool:
        return "PARK_MANAGER" in self.role_codes

    @property
    def enterprise_id(self) -> int | None:
        return self.user.enterprise_id

    def visible_enterprise_ids(self) -> list[int] | None:
        """None = 不受企业级限制；[] = 无可见企业。

        **失败方向必须朝"少给"**：企业管理员（ENTERPRISE 范围）如果没有绑定归属企业，
        说明数据范围算不出来，此时返回空列表（什么都看不到），而不是 None（看到全部）。
        早期播种漏写 `users.enterprise_id`，各接口的 `if auth.enterprise_id:` 守卫就
        整体静默失效，企业管理员实际能看到全园区 128 家企业、1.3 万条账单——
        **静默越权比报错危险得多，报错至少会被发现。**
        """
        if self.data_scope in ("GROUP", "PARK", "DEPARTMENT", "PROJECT"):
            return None
        if self.user.enterprise_id:
            return [self.user.enterprise_id]
        return []

    def can_access_enterprise(self, ent_id: int | None) -> bool:
        vis = self.visible_enterprise_ids()
        if vis is None:
            return True
        return ent_id is not None and ent_id in vis

    def enterprise_scope_clause(self, column):
        """企业级过滤条件；返回 None 表示不加限制。"""
        vis = self.visible_enterprise_ids()
        if vis is None:
            return None
        return column.in_(vis) if vis else column == -1

    def require_enterprise(self, ent_id: int | None, message: str = "企业账号只能访问本企业数据") -> None:
        if not self.can_access_enterprise(ent_id):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=message)

    # ---- 数据权限 ----
    def visible_park_ids(self) -> list[int] | None:
        """None 表示全部园区可见（集团级）。"""
        if self.is_group_admin:
            return None
        if self.park_ids:
            return self.park_ids
        if self.user.park_id:
            return [self.user.park_id]
        return None if self.data_scope == "GROUP" else []

    def can_access_park(self, park_id: int | None) -> bool:
        vis = self.visible_park_ids()
        if vis is None:
            return True
        if park_id is None:
            return False
        return park_id in vis

    def visible_project_ids(self) -> list[int] | None:
        """None 表示不受项目级限制。"""
        if self.data_scope in ("GROUP", "PARK", "DEPARTMENT"):
            return None
        return self.project_ids

    def can_access_project(self, project_id: int) -> bool:
        vis = self.visible_project_ids()
        return vis is None or project_id in vis

    # ---- 功能权限 ----
    def has_perm(self, module: str, action: str = "VIEW") -> bool:
        if self.is_group_admin or "SUPER_ADMIN" in self.role_codes:
            return True
        return f"{module}:{action}" in self.permissions or "*:*" in self.permissions

    def require(self, module: str, action: str = "VIEW") -> None:
        if not self.has_perm(module, action):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"权限不足：需要 {module} 模块的 {action} 权限。当前角色：{self.role_label}",
            )

    @property
    def role_label(self) -> str:
        return "、".join(r.role_name for r in self.roles) or "未分配角色"

    def to_dict(self) -> dict:
        return {
            "id": self.user.id,
            "username": self.user.username,
            "real_name": self.user.real_name,
            "phone": self.user.phone,
            "email": self.user.email,
            "avatar": self.user.avatar,
            "department": self.user.department,
            "position": self.user.position,
            "organization_id": self.user.organization_id,
            "park_id": self.user.park_id,
            "enterprise_id": self.user.enterprise_id,
            "roles": [{"code": r.role_code, "name": r.role_name, "data_scope": r.data_scope} for r in self.roles],
            "role_label": self.role_label,
            "data_scope": self.data_scope,
            "permissions": sorted(self.permissions),
            "visible_park_ids": self.visible_park_ids(),
            "visible_project_ids": self.visible_project_ids(),
            "is_group_admin": self.is_group_admin,
        }


def load_auth_context(db: Session, user: User) -> AuthContext:
    role_ids = db.scalars(select(Role.id).join(Role.__table__.metadata.tables["user_roles"], Role.id ==
                                             Role.__table__.metadata.tables["user_roles"].c.role_id).where(
        Role.__table__.metadata.tables["user_roles"].c.user_id == user.id)).all()
    if not role_ids:
        from app.models import UserRole
        role_ids = db.scalars(select(UserRole.role_id).where(UserRole.user_id == user.id)).all()
    roles = list(db.scalars(select(Role).where(Role.id.in_(role_ids))).all()) if role_ids else []

    perms: set[str] = set()
    if role_ids:
        rows = db.execute(
            select(Permission.module, Permission.action)
            .join(RolePermission, RolePermission.permission_id == Permission.id)
            .where(RolePermission.role_id.in_(role_ids))
        ).all()
        perms = {f"{m}:{a}" for m, a in rows}

    park_ids = list(db.scalars(select(UserParkScope.park_id).where(UserParkScope.user_id == user.id)).all())
    project_ids = list(db.scalars(select(UserProjectScope.project_id).where(UserProjectScope.user_id == user.id)).all())
    return AuthContext(user, roles, perms, park_ids, project_ids)


def _token_candidates(request: Request, oauth_token: str | None) -> list[str]:
    """收集本次请求里所有可能的令牌来源。

    为什么要"收集"而不是"取第一个"：部署在反向代理后面时，网关可能注入或改写
    `Authorization` 头；一旦它覆盖了前端带来的真令牌，鉴权就会永远失败。
    这里把所有来源都列出来逐个尝试验签，任一通过即认定身份——只要有一个来源
    是可信的真令牌就不会被别的来源顶掉。
    """
    out: list[str] = []
    if oauth_token:
        out.append(oauth_token)
    for key in ("X-Token", "X-Access-Token"):
        v = request.headers.get(key)
        if v:
            out.append(v.split()[-1] if " " in v else v)
    for key in ("smartpark_token", "access_token"):
        v = request.cookies.get(key)
        if v:
            out.append(v)
    # 去重且保持顺序
    seen: set[str] = set()
    uniq: list[str] = []
    for t in out:
        if t and t not in seen:
            seen.add(t)
            uniq.append(t)
    return uniq


def get_current_auth(
    request: Request,
    token: Annotated[str | None, Depends(oauth2_scheme)] = None,
    db: Session = Depends(get_db),
) -> AuthContext:
    candidates = _token_candidates(request, token)
    if not candidates:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="未登录或登录已过期")

    payload: dict | None = None
    last_error: Exception | None = None
    for cand in candidates:
        try:
            payload = decode_token(cand)
            break
        except Exception as exc:  # noqa: BLE001 - 换下一个来源继续尝试
            last_error = exc
    if payload is None:
        # 令牌被拒的原因必须可查：曾经出现过"签发成功但自己校验不过"，没有日志只能靠猜。
        logger.warning("本次请求的全部令牌来源都无法校验（共 %d 个，来源=%s，jwt_backend=%s）：%s",
                       len(candidates),
                       [k for k in ("Authorization", "X-Token", "X-Access-Token", "cookie")
                        if request.headers.get(k) or request.cookies.get("smartpark_token")],
                       "python-jose" if _HAS_JOSE else "内置 HMAC 退化实现",
                       last_error)
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="登录凭证无效，请重新登录")
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="登录凭证缺少用户标识")
    user = db.get(User, int(user_id))
    if not user or user.status != "ACTIVE":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="用户不存在或已被禁用")
    return load_auth_context(db, user)


CurrentAuth = Annotated[AuthContext, Depends(get_current_auth)]
DbSession = Annotated[Session, Depends(get_db)]


def perm_guard(module: str, action: str = "VIEW"):
    """路由级权限依赖工厂。"""

    def _guard(auth: CurrentAuth) -> AuthContext:
        auth.require(module, action)
        return auth

    return _guard
